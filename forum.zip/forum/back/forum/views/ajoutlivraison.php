<?php
include "../entities/forum.php";
include "../core/forumc.php";
if(isset($_POST['nom']) and isset($_POST['adresse']) and isset($_POST['date']) and isset($_POST['etat']) and isset($_POST['total']) and isset($_POST['livreur'])) 
{
$forum1=new forum($_POST['id'],$_POST['nom'],$_POST['adresse'],$_POST['total'],$_POST['date'],$_POST['etat'],$_POST['livreur']);
$forum1c= new forumc();
$forum1c->ajouterforum($forum1);
header('Location: afficherforum.php');
}


	

?>
