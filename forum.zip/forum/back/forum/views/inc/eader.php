<?php
require "../config.php";
//C:\wamp\www\Projet Web\config.php
require "../entities/panier_class.php";
//C:\wamp\www\Projet Web\entities\panier_class.php
$config=new config();
$panier=new panier();

?>