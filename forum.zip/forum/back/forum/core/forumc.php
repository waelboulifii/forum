<?PHP
include "../config.php";

class forumc {

	
	function ajouterforum($forum){
		$sql="insert into forum(id,nom,adresse,total,date,etat,livreur) values 
(:id,:nom,:adresse,:total,:date,:etat,:livreur)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
        $id=$forum->getid();
        $nom=$forum->getNom();
        $prenom=$forum->getadresse();
        $note=$forum->gettotale();
        $classe=$forum->getdate();
        $class=$forum->getetat();
         $livreur=$forum->getlivreur();
        //lier variable => paramètre
        $req->bindValue(':id',$id);
		$req->bindValue(':nom',$nom);
		$req->bindValue(':adresse',$prenom);
		$req->bindValue(':total',$note);
        $req->bindValue(':date',$classe);
        $req->bindValue(':etat',$class);
          $req->bindValue(':livreur',$livreur);
            $req->execute();
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
    }
    function afficherforum(){
		$sql="SElECT * From forum";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
	function supprimerforum($id){
		$sql="DELETE FROM forum where id= :id";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':id',$id);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function modifierforum($forum,$id){
		$sql="UPDATE forum SET id=:idd, nom=:nom,adresse=:adresse,etat=:etat,date=:date,total=:total WHERE id=:id";
		$db = config::getConnexion();
try{

    $req=$db->prepare($sql);
    $idd=$forum->getid();
    $nom=$forum->getNom();
    $prenom=$forum->getadresse();
    $note=$forum->gettotale();
    $classe=$forum->getdate();
    $class=$forum->getetat();
		$datas = array(':idd'=>$idd, ':id'=>$id, ':nom'=>$nom,':adresse'=>$prenom,':total'=>$note,':date'=>$classe,':etat'=>$class);
		//lier variable => paramètre
		$req->bindValue(':idd',$idd);
		$req->bindValue(':id',$id);
		$req->bindValue(':nom',$nom);
		$req->bindValue(':adresse',$prenom);
		$req->bindValue(':total',$note);
        $req->bindValue(':etat',$class);
        $req->bindValue(':date',$classe);
		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
	function recupererforum($id){
		$sql="SELECT * from forum where id=$id";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	/*function rechercherListeEmployes($tarif){
		$sql="SELECT * from employe where tarifHoraire=$tarif";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }*/
	}

    
    
    ?>