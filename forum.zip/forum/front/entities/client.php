<?php
  class client
  {
    private $user_name;
    private $preuser_name;
    private $telephone;
    private $adresse;
    private $email;
    private $login;
    private $mdp;

    function __construct($user_name,$preuser_name,$telephone,$adresse,$email,$login,$mdp)
    {
		$this->user_name=$user_name;
		$this->preuser_name=$preuser_name;
		$this->telephone=$telephone;
        $this->adresse=$adresse;
        $this->email=$email;
        $this->login=$login;
        $this->mdp=$mdp;
    }
    function getuser_name()
    {
		return $this->user_name;
	}
    function getPreuser_name()
    {
		return $this->preuser_name;
	}
    function gettel()
    {
		return $this->telephone;
	}
    function getadresse()
    {
		return $this->adresse;
    }
    function getemail()
    {
		return $this->email;
    }
    function getlogin()
    {
		return $this->login;
    }
    function getmdp()
    {
		return $this->mdp;
	}
    function setuser_name($user_name)
    {
		$this->user_name=$user_name;
	}
    function setPreuser_name($preuser_name)
    {
		$this->preuser_name=$preuser_name;
	}
    function settel($telephone)
    {
		$this->tel=$telephone;
	}
    function setadresse($adresse)
    {
		$this->adresse=$adresse;
    }
    function setmail($email)
    {
		$this->mail=$email;
    }
    function setlogin($login)
    {
		$this->login=$login;
    }
    function setmdp($mdp)
    {
		$this->mdp=$mdp;
	}
	
}
?>



	
	