<?php
require  '../views/inc/eader.php';

$json=array('error' => true);
if(isset($_GET['id']))
{
    $id=$_GET['id'];
    $sql = "SELECT id FROM produit WHERE id=:id";
    $tab=array('id'=>$_GET['id']);
    $db = config::getConnexion();
    $req = $db->prepare($sql);
    $req->execute($tab);
    $product=$req->fetchAll(PDO::FETCH_OBJ);
    if(empty($product))
    {
        $json['message']="Ce produit n'existe pas!";
    }

    $panier->add($product[0]->id);
    $json['error']=false;
    $json['message']='Le produit a bien ete ajoute a votre panier';
   
}
else
{
    $json['message']="Vous n'avez selectionne de produit a ajouter au panier";
}

echo json_encode($json);
?>
