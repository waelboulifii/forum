<?PHP
include "../core/forumc.php";
$forum1c=new forumc();
if (isset($_POST["id"])){
	$forum1c->supprimerforum($_POST["id"]);
	header('Location: checkout.php');
}

?>